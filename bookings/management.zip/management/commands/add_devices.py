from django.core.management.base import BaseCommand
from bookings.models import Device

class Command(BaseCommand):
    help = 'Adds multiple device types to the database'

    def handle(self, *args, **kwargs):
        # List of common device names
        device_names = [
            'Laptop', 'Mobile', 'Desktop', 'Tablet', 'Smartwatch', 'Headphones', 
            'Keyboard', 'Mouse', 'Printer', 'Monitor', 'Webcam', 'Speakers', 
            'Charger', 'Power Bank', 'External Hard Drive', 'Flash Drive', 
            'Router', 'Gaming Console', 'Graphics Card', 'Motherboard', 
            'Processor', 'RAM', 'Hard Drive', 'SSD', 'Cooling Pad', 
            'Docking Station', 'Projector', 'TV', 'Camera', 'Microphone'
        ]

        # Create a list of Device objects
        devices = [Device(name=device_name) for device_name in device_names]

        # Use bulk_create to insert all devices in one query
        Device.objects.bulk_create(devices)

        self.stdout.write(self.style.SUCCESS(f'{len(devices)} devices added successfully!'))
