from django.core.management.base import BaseCommand
from bookings.models import DeviceModel, DeviceProblem

class Command(BaseCommand):
    help = 'Adds multiple device problems to the database'

    def handle(self, *args, **kwargs):
        # Get all device models
        device_models = DeviceModel.objects.all()

        # Define common problems for each device model
        device_problems = {
            'iPhone 12': ['Screen flickering', 'Battery draining quickly', 'Overheating'],
            'Galaxy S21': ['Touchscreen not responding', 'Battery draining fast', 'Charging issues'],
            'XPS 13': ['Keyboard not working', 'Overheating', 'Screen flickering'],
            'MacBook Pro': ['Slow performance', 'Overheating', 'Battery not charging'],
            # Add more models and problems as needed
        }

        # Prepare the list of DeviceProblem objects
        problems = []
        for device_model in device_models:
            if device_model.name in device_problems:
                for problem_desc in device_problems[device_model.name]:
                    problems.append(DeviceProblem(description=problem_desc, device_model=device_model))

        # Bulk create the device problems
        DeviceProblem.objects.bulk_create(problems)

        self.stdout.write(self.style.SUCCESS(f'{len(problems)} device problems added successfully!'))
