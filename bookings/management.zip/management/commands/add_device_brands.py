from django.core.management.base import BaseCommand
from bookings.models import Device, DeviceBrand

class Command(BaseCommand):
    help = 'Adds multiple device brands to the database'

    def handle(self, *args, **kwargs):
        # Get the devices
        devices = Device.objects.all()

        # Define brands for each device type
        device_brands = {
            'Laptop': ['Dell', 'HP', 'Lenovo', 'Apple', 'Asus'],
            'Mobile': ['Samsung', 'Apple', 'OnePlus', 'Nokia', 'Huawei'],
            'Desktop': ['Acer', 'HP', 'Lenovo', 'Apple'],
            'Tablet': ['Samsung', 'Apple', 'Lenovo'],
            # Add more devices and brands as needed
        }

        # Prepare the list of DeviceBrand objects
        brands = []
        for device in devices:
            if device.name in device_brands:
                for brand_name in device_brands[device.name]:
                    brands.append(DeviceBrand(name=brand_name, device=device))

        # Bulk create the brands
        DeviceBrand.objects.bulk_create(brands)

        self.stdout.write(self.style.SUCCESS(f'{len(brands)} device brands added successfully!'))
