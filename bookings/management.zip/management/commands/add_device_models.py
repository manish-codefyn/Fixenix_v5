from django.core.management.base import BaseCommand
from bookings.models import DeviceBrand, DeviceModel

class Command(BaseCommand):
    help = 'Adds multiple device models to the database'

    def handle(self, *args, **kwargs):
        # Get the device brands
        device_brands = DeviceBrand.objects.all()

        # Define models for each device brand
        device_models = {
            'Apple': ['iPhone 12', 'iPhone 13', 'iPhone 14', 'MacBook Pro'],
            'Samsung': ['Galaxy S21', 'Galaxy S22', 'Galaxy Note 20'],
            'Dell': ['XPS 13', 'Inspiron 15'],
            'HP': ['Spectre x360', 'Pavilion 14'],
            # Add more brands and models as needed
        }

        # Prepare the list of DeviceModel objects
        models = []
        for brand in device_brands:
            if brand.name in device_models:
                for model_name in device_models[brand.name]:
                    models.append(DeviceModel(name=model_name, device_brand=brand))

        # Bulk create the device models
        DeviceModel.objects.bulk_create(models)

        self.stdout.write(self.style.SUCCESS(f'{len(models)} device models added successfully!'))
